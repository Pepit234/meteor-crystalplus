# CrystalPlus (Meteor Client 1.21.11)
Módulos: auto-crystal-plus, speed-mine-plus, auto-mine-plus.
Requiere Meteor Client 1.21.11 en la carpeta mods.
