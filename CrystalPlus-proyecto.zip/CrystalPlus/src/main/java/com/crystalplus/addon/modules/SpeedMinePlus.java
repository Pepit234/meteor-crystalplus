package com.crystalplus.addon.modules;

import com.crystalplus.addon.CrystalPlusAddon;
import com.crystalplus.addon.util.NetUtil;
import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * SpeedMinePlus: minado por paquetes con secuencia válida, cambio silencioso de herramienta
 * y rebreak instantáneo. Pensado para trabajar junto a AutoMinePlus.
 */
public class SpeedMinePlus extends Module {
    public enum SwitchMode { None, Normal, Silent }
    public enum RotateMode { None, Normal, Silent }
    public enum RebreakMode { Off, Fast, Instant }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRebreak = settings.createGroup("Rebreak");
    private final SettingGroup sgChecks = settings.createGroup("Checks");
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final EnumSetting<SwitchMode> switchMode = sgGeneral.add(new EnumSetting.Builder<SwitchMode>()
        .name("switch").description("Cambio a la herramienta más rápida (solo hotbar).").defaultValue(SwitchMode.Silent).build());
    private final DoubleSetting range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range").description("Alcance. Un servidor vanilla rechaza bloques a más de ~5.5.").defaultValue(5.0).min(1.0).sliderRange(1.0, 8.0).build());
    private final DoubleSetting speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed").description("Progreso necesario para romper (1.0 = normal, 0.7 = mínimo que acepta un servidor vanilla).")
        .defaultValue(1.0).min(0.5).max(1.0).sliderRange(0.5, 1.0).build());
    private final EnumSetting<RotateMode> rotate = sgGeneral.add(new EnumSetting.Builder<RotateMode>()
        .name("rotate").description("Rotación al romper.").defaultValue(RotateMode.None).build());
    private final BoolSetting switchReset = sgGeneral.add(new BoolSetting.Builder()
        .name("switch-reset").description("Reinicia el progreso si cambias de slot a mano.").defaultValue(true).build());

    private final EnumSetting<RebreakMode> rebreak = sgRebreak.add(new EnumSetting.Builder<RebreakMode>()
        .name("rebreak").description("Off: una vez. Fast: vuelve a minar normal. Instant: rompe al instante cuando reaparece.")
        .defaultValue(RebreakMode.Instant).build());
    private final IntSetting instantDelay = sgRebreak.add(new IntSetting.Builder()
        .name("instant-delay").description("Ticks entre disparos instantáneos.").defaultValue(0).min(0).sliderRange(0, 10).build());
    private final IntSetting instantTimeout = sgRebreak.add(new IntSetting.Builder()
        .name("instant-timeout").description("Ticks sin bloque antes de soltar el objetivo.").defaultValue(60).min(1).sliderRange(1, 400).build());
    private final BoolSetting async = sgRebreak.add(new BoolSetting.Builder()
        .name("async").description("Sigue disparando aunque el bloque esté en aire (no espera a que reaparezca).").defaultValue(false).build());

    private final BoolSetting onGroundCheck = sgChecks.add(new BoolSetting.Builder()
        .name("on-ground-check").description("Solo mina si estás en el suelo.").defaultValue(false).build());
    private final BoolSetting whileEating = sgChecks.add(new BoolSetting.Builder()
        .name("while-eating").description("Mina mientras usas un ítem.").defaultValue(true).build());

    private final BoolSetting render = sgRender.add(new BoolSetting.Builder()
        .name("render").description("Dibuja el bloque y su progreso.").defaultValue(true).build());

    // ---- Estado ----
    private BlockPos pos;
    private Direction dir = Direction.UP;
    private BlockState state;
    private int priority;
    private double progress;
    private boolean started, instant, brokenHandled, awaiting;
    private int airTicks, sinceFire, attempts, lastSelected = -1;
    private long lastFire;
    private int brokenCount;

    public SpeedMinePlus() {
        super(CrystalPlusAddon.CATEGORY, "speed-mine-plus", "Minado por paquetes con rebreak instantáneo (usado también por auto-mine-plus).");
    }

    // ---------- API pública (la usa AutoMinePlus) ----------
    public BlockPos getPos() { return pos; }
    public boolean isBusy() { return pos != null; }
    public boolean isInstant() { return instant; }
    public int getPriority() { return priority; }
    public double getRange() { return range.get(); }

    public boolean inRange(BlockPos p) {
        return mc.player != null && mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)) <= range.get();
    }

    public boolean canMine(BlockPos p) {
        if (mc.world == null || !inRange(p)) return false;
        BlockState s = mc.world.getBlockState(p);
        return !s.isAir() && !s.isReplaceable() && s.getHardness(mc.world, p) >= 0 && s.getFluidState().isEmpty();
    }

    /** Pide minar un bloque. Mayor prioridad reemplaza a menor. */
    public boolean handle(BlockPos p, int prio) {
        if (mc.player == null || mc.world == null) return false;
        if (pos != null && pos.equals(p)) return false;
        if (pos != null && prio < priority) return false;
        if (!canMine(p)) return false;

        cancel(true);
        pos = p.toImmutable();
        priority = prio;
        state = mc.world.getBlockState(pos);
        dir = facing(pos);
        progress = 0;
        started = false;
        instant = false;
        brokenHandled = false;
        awaiting = false;
        airTicks = 0;
        sinceFire = 99;
        attempts = 0;
        lastSelected = mc.player.getInventory().getSelectedSlot();
        start();
        return true;
    }

    @Override
    public void onDeactivate() {
        cancel(true);
    }

    @Override
    public String getInfoString() {
        if (pos == null) return null;
        if (instant) return "rebreak";
        return (int) Math.min(100, progress / speed.get() * 100) + "%";
    }

    // ---------- Eventos ----------
    @EventHandler
    private void onStartBreaking(StartBreakingBlockEvent event) {
        if (mc.player == null) return;
        event.cancel();
        handle(event.blockPos, 10);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (pos == null || mc.player == null || mc.world == null || mc.getNetworkHandler() == null) return;

        if (!inRange(pos)) {
            cancel(true);
            return;
        }
        if (onGroundCheck.get() && !mc.player.isOnGround()) return;
        if (!whileEating.get() && mc.player.isUsingItem()) return;

        int selected = mc.player.getInventory().getSelectedSlot();
        if (switchReset.get() && lastSelected != -1 && selected != lastSelected && !instant) progress = 0;
        lastSelected = selected;

        sinceFire++;
        BlockState cur = mc.world.getBlockState(pos);
        long now = System.currentTimeMillis();

        // --- El bloque ya no está (roto o aún no reaparece) ---
        if (cur.isAir() || cur.isReplaceable()) {
            if (!brokenHandled) onBroken();
            if (pos == null) return;
            if (!instant) return;

            airTicks++;
            if (airTicks > instantTimeout.get()) {
                cancel(false);
                return;
            }
            if (async.get() && sinceFire > instantDelay.get()) fireBreak();
            return;
        }

        // --- Hay bloque sólido ---
        airTicks = 0;
        state = cur;
        if (brokenHandled) {
            brokenHandled = false;
            awaiting = false;
            attempts = 0;
            if (!instant) {
                started = false;
                progress = 0;
            }
        }

        if (!started) {
            start();
            return;
        }

        if (instant) {
            if (sinceFire > instantDelay.get() && (!awaiting || now - lastFire > 350)) fireBreak();
            return;
        }

        progress += BlockUtils.getBreakDelta(toolSlot(cur), cur);

        if (progress >= speed.get()) {
            if (!awaiting) {
                fireBreak();
            } else if (now - lastFire > 400) {
                // El servidor no confirmó: reintenta y, si falla, reinicia el minado.
                if (attempts >= 3) {
                    started = false;
                    progress = 0;
                    awaiting = false;
                    attempts = 0;
                } else {
                    fireBreak();
                }
            }
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!render.get() || pos == null) return;

        double frac = instant ? 1.0 : Math.max(0.0, Math.min(1.0, progress / speed.get()));
        int r = (int) (255 * (1.0 - frac));
        int g = (int) (255 * frac);
        Color side = instant ? new Color(80, 160, 255, 40) : new Color(r, g, 60, 40);
        Color line = instant ? new Color(80, 160, 255, 255) : new Color(r, g, 60, 255);

        double s = 0.5 * frac;
        double cx = pos.getX() + 0.5, cy = pos.getY() + 0.5, cz = pos.getZ() + 0.5;
        event.renderer.box(cx - s, cy - s, cz - s, cx + s, cy + s, cz + s, side, line, ShapeMode.Both, 0);
        event.renderer.box(pos, new Color(0, 0, 0, 0), line, ShapeMode.Lines, 0);
    }

    // ---------- Lógica ----------
    private void start() {
        if (pos == null) return;
        final BlockPos p = pos;
        final Direction d = dir;
        NetUtil.sendSequenced(seq -> new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, p, d, seq));
        NetUtil.send(new HandSwingC2SPacket(Hand.MAIN_HAND));
        started = true;
        progress = 0;
        awaiting = false;
    }

    private void onBroken() {
        brokenHandled = true;
        awaiting = false;
        brokenCount++;
        switch (rebreak.get()) {
            case Off -> cancel(false);
            case Fast -> {
                progress = 0;
                started = false;
            }
            case Instant -> {
                instant = true;
                airTicks = 0;
            }
        }
    }

    private void fireBreak() {
        if (pos == null) return;
        final BlockPos p = pos;
        final Direction d = dir;
        final SwitchMode mode = switchMode.get();
        final int tool = toolSlot(state != null ? state : mc.world.getBlockState(p));
        final int selected = mc.player.getInventory().getSelectedSlot();

        Runnable action = () -> {
            boolean swapped = false;
            if (mode != SwitchMode.None && tool != selected && tool >= 0 && tool <= 8) {
                swapped = InvUtils.swap(tool, mode == SwitchMode.Silent);
            }
            NetUtil.sendSequenced(seq -> new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, p, d, seq));
            NetUtil.send(new HandSwingC2SPacket(Hand.MAIN_HAND));
            if (swapped && mode == SwitchMode.Silent) InvUtils.swapBack();
        };

        lastFire = System.currentTimeMillis();
        sinceFire = 0;
        awaiting = true;
        attempts++;

        Vec3d c = Vec3d.ofCenter(p);
        switch (rotate.get()) {
            case Normal -> Rotations.rotate(Rotations.getYaw(c), Rotations.getPitch(c), 50, action);
            case Silent -> {
                NetUtil.send(new PlayerMoveC2SPacket.LookAndOnGround(
                    (float) Rotations.getYaw(c), (float) Rotations.getPitch(c),
                    mc.player.isOnGround(), mc.player.horizontalCollision));
                action.run();
            }
            default -> action.run();
        }
    }

    private int toolSlot(BlockState s) {
        int selected = mc.player.getInventory().getSelectedSlot();
        if (switchMode.get() == SwitchMode.None) return selected;
        FindItemResult tool = InvUtils.findFastestTool(s);
        return tool.found() && tool.slot() <= 8 ? tool.slot() : selected;
    }

    private Direction facing(BlockPos p) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d c = Vec3d.ofCenter(p);
        return Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
    }

    private void cancel(boolean abort) {
        if (abort && pos != null && started && !brokenHandled && mc.world != null && mc.getNetworkHandler() != null) {
            final BlockPos p = pos;
            final Direction d = dir;
            NetUtil.sendSequenced(seq -> new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.ABORT_DESTROY_BLOCK, p, d, seq));
        }
        pos = null;
        state = null;
        progress = 0;
        started = false;
        instant = false;
        brokenHandled = false;
        awaiting = false;
        airTicks = 0;
        attempts = 0;
    }
}
