package com.crystalplus.addon.modules;

import com.crystalplus.addon.CrystalPlusAddon;
import com.crystalplus.addon.util.NetUtil;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.RaycastContext;
import org.joml.Vector3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * AutoCrystalPlus v3 (Meteor Client 1.21.11).
 * Ataca y coloca cristales según el daño calculado. Incluye faceplace, base-place con air-place,
 * predicción, rotaciones, cambio silencioso, modo de seguridad ajustable (Normal / Relaxed / Off)
 * y un estado siempre visible que dice exactamente por qué actúa o por qué no.
 */
public class AutoCrystalPlus extends Module {
    public enum SwitchMode { None, Normal, Silent }
    public enum SpeedMode { Custom, Dynamic }
    public enum TargetMode { Players, All }
    public enum SwingMode { None, Default, Packet }
    public enum EatMode { None, Attack, Place, Both }
    public enum BreakMode { Smart, Any }
    public enum Safety { Normal, Relaxed, Off }

    private static final int R_LOW = 0, R_SELF = 1, R_RATIO = 2, R_SUICIDE = 3, R_RANGE = 4, R_RECENT = 5;

    // ---------- Grupos ----------
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAttack = settings.createGroup("Attack");
    private final SettingGroup sgPlace = settings.createGroup("Place");
    private final SettingGroup sgMisc = settings.createGroup("Miscellaneous");
    private final SettingGroup sgPrediction = settings.createGroup("Prediction");
    private final SettingGroup sgFace = settings.createGroup("Faceplace");
    private final SettingGroup sgBase = settings.createGroup("BasePlace");
    private final SettingGroup sgDamage = settings.createGroup("Damage");
    private final SettingGroup sgRender = settings.createGroup("Render");

    // ---------- General ----------
    private final EnumSetting<TargetMode> targetMode = en(sgGeneral, "target", "Objetivos válidos.", TargetMode.All);
    private final DoubleSetting enemyRange = dbl(sgGeneral, "enemy-range", "Distancia máxima a los objetivos.", 10.0, 1.0, 20.0);
    private final BoolSetting ignoreNaked = bool(sgGeneral, "ignore-naked", "Ignora jugadores sin armadura.", false);
    private final EnumSetting<SwitchMode> switchMode = en(sgGeneral, "switch", "Cómo cambiar al cristal / espada / obsidiana.", SwitchMode.Silent);
    private final BoolSetting rotate = bool(sgGeneral, "rotate", "Rota hacia el cristal / bloque.", false);
    private final EnumSetting<SwingMode> swingMode = en(sgGeneral, "swing", "Tipo de swing.", SwingMode.Default);
    private final BoolSetting debug = bool(sgGeneral, "debug", "Escribe en el chat por qué no actúa (el estado siempre se ve junto al nombre del módulo).", false);

    // ---------- Attack ----------
    private final BoolSetting attack = bool(sgAttack, "attack", "Rompe cristales.", true);
    private final EnumSetting<BreakMode> breakMode = en(sgAttack, "break-mode", "Smart: solo los que hacen daño. Any: también cristales que pongas a mano (mientras no te maten).", BreakMode.Smart);
    private final EnumSetting<SpeedMode> speedMode = en(sgAttack, "speed-mode", "Custom usa la velocidad fija; Dynamic la baja con el ping.", SpeedMode.Custom);
    private final DoubleSetting speed = dbl(sgAttack, "speed", "Golpes por segundo.", 17.0, 1.0, 20.0);
    private final DoubleSetting attackRange = dbl(sgAttack, "range", "Alcance de ataque.", 4.5, 1.0, 6.0);
    private final DoubleSetting wallsRange = dbl(sgAttack, "walls-range", "Alcance de ataque a través de bloques.", 3.0, 0.0, 6.0);
    private final BoolSetting instant = bool(sgAttack, "instant", "Golpea el cristal en cuanto aparece (paquete de spawn).", true);
    private final BoolSetting inhibit = bool(sgAttack, "inhibit", "No vuelve a golpear el mismo cristal enseguida.", true);
    private final BoolSetting antiWeakness = bool(sgAttack, "anti-weakness", "Cambia a espada con Weakness.", true);
    private final BoolSetting godSync = bool(sgAttack, "god-sync", "Golpea los siguientes IDs justo al colocar (puede ser detectado).", false);
    private final IntSetting predictions = num(sgAttack, "predictions", "Cuántos IDs adelante golpea con god-sync.", 2, 1, 6);

    // ---------- Place ----------
    private final BoolSetting place = bool(sgPlace, "place", "Coloca cristales.", true);
    private final IntSetting placeDelay = num(sgPlace, "delay", "Retraso entre colocaciones (ms).", 0, 0, 500);
    private final DoubleSetting placeRange = dbl(sgPlace, "range", "Alcance de colocación.", 4.5, 1.0, 6.0);
    private final DoubleSetting placeWalls = dbl(sgPlace, "place-walls-range", "Alcance para colocar donde no ves la base.", 3.0, 0.0, 6.0);
    private final DoubleSetting scanRadius = dbl(sgPlace, "scan-radius", "Radio de búsqueda alrededor del objetivo.", 3.0, 1.0, 5.0);
    private final BoolSetting strictDirection = bool(sgPlace, "strict-direction", "Usa la cara más cercana y visible del bloque.", false);

    // ---------- Miscellaneous ----------
    private final EnumSetting<EatMode> whileEating = en(sgMisc, "while-eating", "Qué se permite mientras usas un ítem.", EatMode.Both);
    private final BoolSetting pauseOnXp = bool(sgMisc, "pause-on-xp", "Pausa al lanzar botellas de XP.", true);
    private final BoolSetting pauseOnPearl = bool(sgMisc, "pause-on-pearl", "Pausa al lanzar perlas.", true);
    private final BoolSetting pauseOnSecondary = bool(sgMisc, "pause-on-secondary", "Pausa si usas clic derecho con otro ítem.", false);
    private final BoolSetting gameLoop = bool(sgMisc, "game-loop", "Ejecuta la lógica en cada frame en vez de cada tick.", false);
    private final IntSetting loopDelay = num(sgMisc, "loop-delay", "Retraso del game loop (ms).", 20, 0, 200);

    // ---------- Prediction ----------
    private final IntSetting extrapolation = num(sgPrediction, "extrapolation", "Ticks de movimiento que se predicen del objetivo.", 0, 0, 10);

    // ---------- Faceplace ----------
    private final DoubleSetting faceHealth = dbl(sgFace, "health", "Faceplace si el objetivo tiene esta vida o menos.", 8.0, 0.0, 36.0);
    private final IntSetting faceArmor = num(sgFace, "armor-percentage", "Faceplace si una pieza de armadura baja de este %.", 10, 0, 100);
    private final DoubleSetting faceMinDamage = dbl(sgFace, "min-damage", "Daño mínimo en faceplace.", 1.0, 0.0, 10.0);
    private final KeybindSetting faceBind = sgFace.add(new KeybindSetting.Builder()
        .name("force-bind").description("Mantén esta tecla para forzar faceplace.")
        .defaultValue(Keybind.none()).build());

    // ---------- BasePlace ----------
    private final BoolSetting basePlace = bool(sgBase, "base-place", "Coloca obsidiana si no hay una base válida (necesitas obsidiana en la hotbar).", true);
    private final IntSetting baseDelay = num(sgBase, "base-delay", "Retraso entre bases (ms).", 120, 0, 1000);
    private final BoolSetting airPlace = bool(sgBase, "air-place", "Coloca la obsidiana en el aire, sin bloque de apoyo (servidores con anticheat estricto la bloquean).", true);

    // ---------- Damage ----------
    private final EnumSetting<Safety> safety = en(sgDamage, "safety", "Normal: max-self, ratio y anti-suicide. Relaxed: solo evita que te mate. Off: sin ninguna comprobación (solo para pruebas).", Safety.Normal);
    private final DoubleSetting minDamage = dbl(sgDamage, "min-damage", "Daño mínimo al enemigo.", 6.0, 0.0, 36.0);
    private final DoubleSetting maxSelf = dbl(sgDamage, "max-self", "Daño máximo permitido a ti (en creativo no cuenta).", 10.0, 0.0, 36.0);
    private final DoubleSetting ratio = dbl(sgDamage, "ratio", "Relación mínima daño enemigo / daño propio.", 1.5, 0.0, 10.0);
    private final BoolSetting lethal = bool(sgDamage, "lethal-override", "Si el cristal mata al objetivo, ignora min-damage y ratio.", true);
    private final BoolSetting antiSuicide = bool(sgDamage, "anti-suicide", "Con safety Normal, nunca coloca ni rompe si puede matarte.", true);
    private final BoolSetting assumeProtection = bool(sgDamage, "assume-protection", "Asume Protección/Blast con armadura alta.", true);

    // ---------- Render ----------
    private final BoolSetting render = bool(sgRender, "render", "Dibuja el bloque de colocación.", true);
    private final EnumSetting<ShapeMode> shapeMode = en(sgRender, "shape-mode", "Modo de forma.", ShapeMode.Both);
    private final ColorSetting sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color").description("Color de los lados.")
        .defaultValue(new SettingColor(255, 0, 170, 40)).build());
    private final ColorSetting lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").description("Color de las líneas.")
        .defaultValue(new SettingColor(255, 0, 170, 255)).build());
    private final IntSetting fade = num(sgRender, "fade-time", "Tiempo visible tras colocar (ms).", 300, 0, 2000);
    private final BoolSetting renderDamageText = bool(sgRender, "render-damage", "Muestra el daño sobre el bloque colocado.", true);

    // ---------- Estado ----------
    private final Map<UUID, Vec3d> lastPos = new HashMap<>();
    private final Map<UUID, Vec3d> velocity = new HashMap<>();
    private final Map<Integer, Long> hitTimes = new HashMap<>();
    private final Map<BlockPos, Long> recentPlace = new HashMap<>();
    /** Caché de bases de obsidiana recién colocadas (air-place / base-place). Evita doble colocación y permite reutilizar la base antes de que el cliente sincronice el bloque. */
    private final Map<BlockPos, Long> placedBlockCache = new HashMap<>();
    private static final long PLACED_CACHE_TTL = 2000L;
    private final ArrayDeque<Long> attackStamps = new ArrayDeque<>();
    private final int[] rej = new int[6];
    private int cBases, crystalsSeen;
    private boolean noCrystals, acted;
    private int skippedImmune;
    private double minSelfSeen;
    private String actedText = "";
    private volatile int highestId;
    private long lastAttack, lastPlace, lastBase, lastLoop, lastDebug;
    private String lastPrinted = "";
    private BlockPos pendingBase;
    private long pendingTime, lastBaseScan, baseBlockedUntil;
    private int baseFails;
    private boolean virtualBase;
    private BlockPos renderPos;
    private long renderTime;
    private double renderDamage;
    private String statusText;

    public AutoCrystalPlus() {
        super(CrystalPlusAddon.CATEGORY, "auto-crystal-plus", "AutoCrystal avanzado: ataca, coloca, base-place, air-place, faceplace y estado en vivo.");
    }

    // ---------- Helpers de ajustes ----------
    private static BoolSetting bool(SettingGroup g, String n, String d, boolean def) {
        return g.add(new BoolSetting.Builder().name(n).description(d).defaultValue(def).build());
    }

    private static IntSetting num(SettingGroup g, String n, String d, int def, int min, int max) {
        return g.add(new IntSetting.Builder().name(n).description(d).defaultValue(def).min(min).sliderRange(min, max).build());
    }

    private static DoubleSetting dbl(SettingGroup g, String n, String d, double def, double min, double max) {
        return g.add(new DoubleSetting.Builder().name(n).description(d).defaultValue(def).min(min).sliderRange(min, max).build());
    }

    private static <T extends Enum<T>> EnumSetting<T> en(SettingGroup g, String n, String d, T def) {
        return g.add(new EnumSetting.Builder<T>().name(n).description(d).defaultValue(def).build());
    }

    // ---------- Ciclo de vida ----------
    @Override
    public void onActivate() {
        resetState();
        if (mc.world != null) {
            int max = 0;
            for (Entity e : mc.world.getEntities()) max = Math.max(max, e.getId());
            highestId = max;
        }
        if (debug.get()) info("AC activado. El estado aparece junto al nombre del módulo y en este chat.");
    }

    @Override
    public void onDeactivate() {
        resetState();
    }

    private void resetState() {
        lastPos.clear();
        velocity.clear();
        hitTimes.clear();
        recentPlace.clear();
        placedBlockCache.clear();
        attackStamps.clear();
        renderPos = null;
        statusText = null;
        lastPrinted = "";
        pendingBase = null;
        baseFails = 0;
        baseBlockedUntil = 0;
        virtualBase = false;
    }

    @Override
    public String getInfoString() {
        return statusText;
    }

    // ---------- Eventos ----------
    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;
        updateVelocities();
        if (!gameLoop.get()) runLogic();
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.player == null || mc.world == null) return;
        long now = System.currentTimeMillis();

        if (gameLoop.get() && now - lastLoop >= loopDelay.get()) {
            lastLoop = now;
            runLogic();
        }

        if (render.get() && renderPos != null && now - renderTime <= fade.get()) {
            event.renderer.box(renderPos, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        }
    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if (!render.get() || !renderDamageText.get() || renderPos == null || mc.world == null) return;
        if (System.currentTimeMillis() - renderTime > fade.get()) return;

        Vector3d v = new Vector3d(renderPos.getX() + 0.5, renderPos.getY() + 1.5, renderPos.getZ() + 0.5);
        if (!NametagUtils.to2D(v, 1.0)) return;

        TextRenderer text = TextRenderer.get();
        String label = String.format("%.1f", renderDamage);
        NametagUtils.begin(v);
        text.beginBig();
        double w = text.getWidth(label, true);
        text.render(label, -w / 2.0, 0, new Color(255, 255, 255, 255), true);
        text.end();
        NametagUtils.end();
    }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (!(event.packet instanceof EntitySpawnS2CPacket p)) return;

        if (p.getEntityId() > highestId) highestId = p.getEntityId();

        if (!instant.get() || !attack.get()) return;
        if (p.getEntityType() != EntityType.END_CRYSTAL) return;

        final int id = p.getEntityId();
        final Vec3d at = new Vec3d(p.getX(), p.getY(), p.getZ());
        mc.execute(() -> instantHit(id, at));
    }

    // ---------- Lógica principal ----------
    private void runLogic() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.player.isDead()) return;

        long now = System.currentTimeMillis();
        hitTimes.entrySet().removeIf(e -> now - e.getValue() > 1000);
        recentPlace.entrySet().removeIf(e -> now - e.getValue() > 600);

        Arrays.fill(rej, 0);
        cBases = 0;
        crystalsSeen = 0;
        noCrystals = false;
        acted = false;
        skippedImmune = 0;
        minSelfSeen = Double.MAX_VALUE;

        List<LivingEntity> targets = getTargets();
        if (!targets.isEmpty()) {
            if (attack.get() && allowed(true)) doAttack(targets);
            if (place.get() && allowed(false)) doPlace(targets);
        }

        String s;
        if (targets.isEmpty()) {
            s = skippedImmune > 0
                ? "objetivos en creativo/espectador ignorados"
                : String.format("sin objetivo (a más de %.0f bloques)", enemyRange.get());
        }
        else if (acted) s = actedText;
        else s = diagnose();
        statusText = s;

        if (!acted && debug.get() && !s.equals(lastPrinted) && now - lastDebug > 1500) {
            lastDebug = now;
            lastPrinted = s;
            info("AC: %s", s);
        }
    }

    private String diagnose() {
        if (!attack.get() && !place.get()) return "attack y place apagados";
        if (System.currentTimeMillis() < baseBlockedUntil) return "el servidor revierte la obsidiana (base-place en pausa 10 s)";
        if (place.get() && noCrystals && crystalsSeen == 0) return "sin cristales en hotbar/offhand";
        if (cBases == 0 && crystalsSeen == 0) {
            return basePlace.get() ? "sin base (¿obsidiana en la hotbar?)" : "sin base de obsidiana/bedrock cerca";
        }

        int idx = -1, val = 0;
        for (int i = 0; i < rej.length; i++) {
            if (rej[i] > val) {
                val = rej[i];
                idx = i;
            }
        }
        if (idx == -1) return "ningún cristal llega al daño mínimo";
        if (idx == R_LOW) return String.format("daño bajo (< %.0f)", minDamage.get());
        if (idx == R_SELF) return String.format("daño propio %.0f > max-self %.0f", minSelfSeen, maxSelf.get());
        if (idx == R_RATIO) return "ratio bajo (baja ratio)";
        if (idx == R_SUICIDE) return String.format("te mataría (%.0f daño propio)", minSelfSeen);
        if (idx == R_RANGE) return "fuera de alcance o sin visión";
        return "esperando";
    }

    private boolean allowed(boolean attackAction) {
        boolean using = mc.options.useKey.isPressed();
        if (pauseOnXp.get() && using && holds(Items.EXPERIENCE_BOTTLE)) return false;
        if (pauseOnPearl.get() && using && holds(Items.ENDER_PEARL)) return false;
        if (pauseOnSecondary.get() && using && !holds(Items.END_CRYSTAL)) return false;

        if (mc.player.isUsingItem()) {
            EatMode m = whileEating.get();
            boolean ok = m == EatMode.Both
                || (attackAction && m == EatMode.Attack)
                || (!attackAction && m == EatMode.Place);
            if (!ok) return false;
        }
        return true;
    }

    private boolean holds(Item item) {
        return mc.player.getMainHandStack().isOf(item) || mc.player.getOffHandStack().isOf(item);
    }

    // ---------- Objetivos ----------
    private static Vec3d pos(Entity e) {
        return new Vec3d(e.getX(), e.getY(), e.getZ());
    }

    private void updateVelocities() {
        if (lastPos.size() > 512) {
            lastPos.clear();
            velocity.clear();
        }
        for (Entity en : mc.world.getEntities()) {
            if (!(en instanceof LivingEntity)) continue;
            Vec3d p = pos(en);
            Vec3d old = lastPos.put(en.getUuid(), p);
            if (old != null) velocity.put(en.getUuid(), p.subtract(old));
        }
    }

    /**
     * Jugadores reales en creativo/espectador no se atacan. El jugador falso de Meteor copia TU modo de
     * juego y no está en la lista de jugadores, así que sí cuenta como objetivo.
     */
    private boolean untargetable(PlayerEntity p) {
        if (!p.isCreative() && !p.isSpectator()) return false;
        return mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(p.getUuid()) != null;
    }

    private boolean naked(PlayerEntity p) {
        return p.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
            && p.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
            && p.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
            && p.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }

    private List<LivingEntity> getTargets() {
        List<LivingEntity> list = new ArrayList<>();
        for (Entity en : mc.world.getEntities()) {
            if (!(en instanceof LivingEntity le) || le == mc.player || !le.isAlive()) continue;

            if (le instanceof PlayerEntity p) {
                if (Friends.get().isFriend(p)) continue;
                if (untargetable(p)) {
                    skippedImmune++;
                    continue;
                }
                if (ignoreNaked.get() && naked(p)) continue;
            } else if (targetMode.get() == TargetMode.Players || !(le instanceof HostileEntity)) {
                continue;
            }

            if (mc.player.distanceTo(le) > enemyRange.get()) continue;
            list.add(le);
        }
        list.sort(Comparator.comparingDouble(e -> mc.player.distanceTo(e)));
        return list.size() > 3 ? new ArrayList<>(list.subList(0, 3)) : list;
    }

    private Vec3d predicted(LivingEntity t) {
        Vec3d p = pos(t);
        int ticks = extrapolation.get();
        if (ticks <= 0) return p;
        Vec3d v = velocity.get(t.getUuid());
        if (v == null) return p;
        return p.add(v.x * ticks, 0, v.z * ticks);
    }

    private boolean faceplaceActive(LivingEntity t) {
        if (faceBind.get().isPressed()) return true;
        if (t.getHealth() + t.getAbsorptionAmount() <= faceHealth.get()) return true;
        if (t instanceof PlayerEntity p) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (EquipmentSlot s : slots) {
                ItemStack st = p.getEquippedStack(s);
                if (st.isEmpty() || !st.isDamageable()) continue;
                double pct = (st.getMaxDamage() - st.getDamage()) * 100.0 / st.getMaxDamage();
                if (pct <= faceArmor.get()) return true;
            }
        }
        return false;
    }

    // ---------- Daño ----------
    private boolean selfImmune() {
        return mc.player.isCreative() || mc.player.isSpectator();
    }

    private double selfDamage(Vec3d crystal) {
        if (selfImmune()) return 0;
        return damage(mc.player, pos(mc.player), mc.player.getBoundingBox(), crystal, -1.0);
    }

    private double health() {
        return mc.player.getHealth() + mc.player.getAbsorptionAmount();
    }

    /** true si el cristal no te mata (respeta el modo safety). */
    private boolean selfSafe(Vec3d crystal) {
        if (safety.get() == Safety.Off) return true;
        double self = selfDamage(crystal);
        if (self >= health() - 0.5) {
            rej[R_SUICIDE]++;
            minSelfSeen = Math.min(minSelfSeen, self);
            return false;
        }
        return true;
    }

    /** Devuelve {dañoEnemigo, dañoPropio} o null si el cristal no cumple los filtros. */
    private double[] evaluate(Vec3d crystal, List<LivingEntity> ts) {
        double best = 0;
        boolean bestFace = false, bestLethal = false;

        for (LivingEntity t : ts) {
            Vec3d tp = predicted(t);
            if (tp.distanceTo(crystal) > 12.0) continue;

            boolean face = faceplaceActive(t);
            double need = face ? faceMinDamage.get() : minDamage.get();
            double hp = t.getHealth() + t.getAbsorptionAmount();

            Box tb = t.getBoundingBox().offset(tp.subtract(pos(t)));
            // Cota superior barata antes de lanzar rayos
            if (damage(t, tp, tb, crystal, 1.0) < Math.min(need, hp)) continue;

            double d = damage(t, tp, tb, crystal, -1.0);
            boolean kills = lethal.get() && d >= hp;
            if (d < need && !kills) continue;

            if (d > best) {
                best = d;
                bestFace = face;
                bestLethal = kills;
            }
        }
        if (best <= 0) {
            rej[R_LOW]++;
            return null;
        }

        double self = selfDamage(crystal);
        Safety sf = safety.get();

        if (sf != Safety.Off) {
            boolean checkSuicide = sf == Safety.Relaxed || antiSuicide.get();
            if (checkSuicide && self >= health() - 0.5) {
                rej[R_SUICIDE]++;
                minSelfSeen = Math.min(minSelfSeen, self);
                return null;
            }
            if (sf == Safety.Normal) {
                if (self > maxSelf.get()) {
                    rej[R_SELF]++;
                    minSelfSeen = Math.min(minSelfSeen, self);
                    return null;
                }
                if (!bestFace && !bestLethal && self > 0.5 && best / self < ratio.get()) {
                    rej[R_RATIO]++;
                    return null;
                }
            }
        }
        return new double[]{best, self};
    }

    /** exposureOverride < 0 => calcula la exposición con rayos. */
    private double damage(LivingEntity e, Vec3d p, Box box, Vec3d c, double exposureOverride) {
        double dist = p.distanceTo(c) / 12.0;
        if (dist > 1.0) return 0;

        double exposure = exposureOverride >= 0 ? exposureOverride : exposure(c, box);
        double impact = (1.0 - dist) * exposure;
        double dmg = (int) ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0);

        if (e instanceof PlayerEntity) {
            Difficulty diff = mc.world.getDifficulty();
            if (diff == Difficulty.PEACEFUL) return 0;
            if (diff == Difficulty.EASY) dmg = Math.min(dmg / 2.0 + 1.0, dmg);
            else if (diff == Difficulty.HARD) dmg = dmg * 1.5;
        }

        double armor = e.getAttributeValue(EntityAttributes.ARMOR);
        double tough = e.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
        double reduce = Math.min(20.0, Math.max(armor / 5.0, armor - dmg / (2.0 + tough / 4.0)));
        dmg *= 1.0 - reduce / 25.0;

        if (assumeProtection.get() && armor >= 10) dmg *= 0.6;

        StatusEffectInstance res = e.getStatusEffect(StatusEffects.RESISTANCE);
        if (res != null) dmg *= Math.max(0.0, 1.0 - (res.getAmplifier() + 1) * 0.2);

        return Math.max(0.0, dmg);
    }

    private double exposure(Vec3d src, Box b) {
        double w = b.getLengthX(), h = b.getLengthY(), l = b.getLengthZ();
        double[] xs = {b.minX + w * 0.2, b.maxX - w * 0.2};
        double[] ys = {b.minY + h * 0.1, b.minY + h * 0.5, b.maxY - h * 0.1};
        double[] zs = {b.minZ + l * 0.2, b.maxZ - l * 0.2};

        int hit = 0, total = 0;
        for (double x : xs) {
            for (double y : ys) {
                for (double z : zs) {
                    total++;
                    // Con una base virtual (obsidiana aún sin colocar) todo rayo que baja desde el cristal choca con ella.
                    if (virtualBase && y < src.y - 1.0E-6) continue;
                    BlockHitResult r = mc.world.raycast(new RaycastContext(src, new Vec3d(x, y, z),
                        RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
                    if (r.getType() == HitResult.Type.MISS) hit++;
                }
            }
        }
        return hit / (double) total;
    }

    // ---------- Ataque ----------
    private double attackInterval() {
        double s = speed.get();
        if (speedMode.get() == SpeedMode.Dynamic && mc.getNetworkHandler() != null) {
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            int ping = entry != null ? entry.getLatency() : 0;
            s *= Math.max(0.4, Math.min(1.0, 1.0 - ping / 500.0));
        }
        return 1000.0 / Math.max(1.0, s);
    }

    private boolean crystalReachable(EndCrystalEntity c) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d center = c.getBoundingBox().getCenter();
        double d = eye.distanceTo(center);
        if (d > attackRange.get()) return false;

        BlockHitResult r = mc.world.raycast(new RaycastContext(eye, center,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        boolean visible = r.getType() == HitResult.Type.MISS;
        return visible || d <= wallsRange.get();
    }

    private boolean hasWeakness() {
        StatusEffectInstance weak = mc.player.getStatusEffect(StatusEffects.WEAKNESS);
        if (weak == null) return false;
        StatusEffectInstance str = mc.player.getStatusEffect(StatusEffects.STRENGTH);
        return str == null || str.getAmplifier() <= weak.getAmplifier();
    }

    private void doAttack(List<LivingEntity> ts) {
        long now = System.currentTimeMillis();
        if (now - lastAttack < attackInterval()) return;

        EndCrystalEntity best = null;
        double bestScore = -1, bestDmg = 0;

        for (Entity en : mc.world.getEntities()) {
            if (!(en instanceof EndCrystalEntity c) || !c.isAlive()) continue;
            crystalsSeen++;

            if (!crystalReachable(c)) {
                rej[R_RANGE]++;
                continue;
            }

            Long h = hitTimes.get(c.getId());
            if (inhibit.get() && h != null && now - h < 250) continue;

            double[] ev = evaluate(pos(c), ts);
            double score, dmg = 0;
            if (ev != null) {
                score = ev[0];
                dmg = ev[0];
            } else if (breakMode.get() == BreakMode.Any && selfSafe(pos(c))) {
                score = 0.001;
            } else {
                continue;
            }

            if (score > bestScore) {
                bestScore = score;
                bestDmg = dmg;
                best = c;
            }
        }
        if (best == null) return;

        lastAttack = now;
        hitTimes.put(best.getId(), now);
        attackStamps.addLast(now);
        acted = true;
        actedText = ts.get(0).getName().getString() + " golpe " + String.format("%.1f", bestDmg);
        hitCrystal(best);
    }

    private void hitCrystal(EndCrystalEntity c) {
        final boolean weak = antiWeakness.get() && hasWeakness();
        final FindItemResult sword = weak ? InvUtils.findInHotbar(s -> s.isIn(ItemTags.SWORDS)) : null;
        final SwitchMode mode = switchMode.get();

        Runnable action = () -> {
            boolean swapped = false;
            if (sword != null && sword.found() && mode != SwitchMode.None && sword.slot() <= 8) {
                swapped = InvUtils.swap(sword.slot(), mode == SwitchMode.Silent);
            }
            mc.interactionManager.attackEntity(mc.player, c);
            swing(Hand.MAIN_HAND);
            if (swapped && mode == SwitchMode.Silent) InvUtils.swapBack();
        };

        if (rotate.get()) {
            Vec3d t = c.getBoundingBox().getCenter();
            Rotations.rotate(Rotations.getYaw(t), Rotations.getPitch(t), 50, action);
        } else {
            action.run();
        }
    }

    private void instantHit(int id, Vec3d at) {
        if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) return;
        if (rotate.get() || !allowed(true)) return;
        if (antiWeakness.get() && hasWeakness()) return;

        long now = System.currentTimeMillis();
        if (now - lastAttack < attackInterval() * 0.5) return;

        Vec3d center = at.add(0, 1.0, 0);
        if (mc.player.getEyePos().distanceTo(center) > attackRange.get()) return;

        List<LivingEntity> ts = getTargets();
        if (ts.isEmpty()) return;
        if (evaluate(at, ts) == null && !(breakMode.get() == BreakMode.Any && selfSafe(at))) return;

        lastAttack = now;
        hitTimes.put(id, now);
        attackStamps.addLast(now);
        sendAttackToId(id, at);
        swing(Hand.MAIN_HAND);
    }

    private void sendAttackToId(int id, Vec3d at) {
        EndCrystalEntity fake = new EndCrystalEntity(mc.world, at.x, at.y, at.z);
        fake.setId(id);
        NetUtil.send(PlayerInteractEntityC2SPacket.attack(fake, mc.player.isSneaking()));
    }

    private void swing(Hand hand) {
        switch (swingMode.get()) {
            case None -> { }
            case Default -> mc.player.swingHand(hand);
            case Packet -> NetUtil.send(new HandSwingC2SPacket(hand));
        }
    }

    // ---------- Colocación ----------
    private void doPlace(List<LivingEntity> ts) {
        long now = System.currentTimeMillis();
        if (now - lastPlace < placeDelay.get()) return;

        boolean main = mc.player.getMainHandStack().isOf(Items.END_CRYSTAL);
        boolean off = mc.player.getOffHandStack().isOf(Items.END_CRYSTAL);
        final FindItemResult hb = InvUtils.findInHotbar(Items.END_CRYSTAL);
        final SwitchMode mode = switchMode.get();
        final boolean needSwap = !main && !off;

        if (needSwap && (!hb.found() || hb.slot() > 8 || mode == SwitchMode.None)) {
            noCrystals = true;
            return;
        }

        double[] out = new double[2];
        BlockPos base = findPlace(ts, false, out, now);
        if (base == null) {
            if (basePlace.get()) doBasePlace(ts, now);
            return;
        }

        final BlockPos target = base;
        final Hand hand = (main || !off) ? Hand.MAIN_HAND : Hand.OFF_HAND;
        final Direction dir = placeDir(target);
        final Vec3d hit = Vec3d.ofCenter(target).add(dir.getOffsetX() * 0.5, dir.getOffsetY() * 0.5, dir.getOffsetZ() * 0.5);
        final Vec3d crystalPos = new Vec3d(target.getX() + 0.5, target.getY() + 1.0, target.getZ() + 0.5);

        Runnable action = () -> {
            boolean swapped = false;
            if (needSwap) swapped = InvUtils.swap(hb.slot(), mode == SwitchMode.Silent);
            mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(hit, dir, target, false));
            swing(hand);
            if (godSync.get() && attack.get()) {
                for (int i = 1; i <= predictions.get(); i++) sendAttackToId(highestId + i, crystalPos);
            }
            if (swapped && mode == SwitchMode.Silent) InvUtils.swapBack();
        };

        lastPlace = now;
        recentPlace.put(target.toImmutable(), now);
        renderPos = target;
        renderTime = now;
        renderDamage = out[0];
        acted = true;
        actedText = ts.get(0).getName().getString() + " coloca " + String.format("%.1f", out[0]);

        if (rotate.get()) {
            Rotations.rotate(Rotations.getYaw(hit), Rotations.getPitch(hit), 50, action);
        } else {
            action.run();
        }
    }

    private void doBasePlace(List<LivingEntity> ts, long now) {
        if (now < baseBlockedUntil) return;
        if (now - lastBase < baseDelay.get()) return;
        if (now - lastBaseScan < 80) return;
        lastBaseScan = now;

        // Limpia entradas caducadas de la caché de bloques colocados.
        placedBlockCache.entrySet().removeIf(e -> now - e.getValue() > PLACED_CACHE_TTL);

        // Si ya hay una base pendiente o en caché reciente, no colocar otra (evita doble air-place).
        if (pendingBase != null) {
            boolean solid = !mc.world.getBlockState(pendingBase).isAir();
            long age = now - pendingTime;
            if (solid || age < 800) {
                // Reutilizar: mantener en caché para que findPlace(false) la vea como base válida.
                if (solid) {
                    placedBlockCache.put(pendingBase, now);
                    baseFails = 0;
                } else if (age >= 800) {
                    if (++baseFails >= 3) {
                        baseBlockedUntil = now + 10000;
                        baseFails = 0;
                        placedBlockCache.remove(pendingBase);
                        pendingBase = null;
                        return;
                    }
                }
                return; // no colocar un segundo bloque
            }
            // Demasiado vieja y sigue en aire: descartar y permitir un reintento.
            placedBlockCache.remove(pendingBase);
            pendingBase = null;
        }

        // Si la caché ya tiene una base usable reciente, no buscar ni colocar otra.
        for (Map.Entry<BlockPos, Long> e : placedBlockCache.entrySet()) {
            if (now - e.getValue() <= PLACED_CACHE_TTL) {
                BlockPos cached = e.getKey();
                if (!mc.world.getBlockState(cached.up()).isAir()) continue;
                pendingBase = cached;
                pendingTime = e.getValue();
                return;
            }
        }

        FindItemResult obs = InvUtils.findInHotbar(Items.OBSIDIAN);
        if (!obs.found()) return;

        double[] out = new double[2];
        BlockPos pos = findPlace(ts, true, out, now);
        if (pos == null) return;

        // No recolocar sobre una posición ya cacheada.
        Long cachedAt = placedBlockCache.get(pos);
        if (cachedAt != null && now - cachedAt < PLACED_CACHE_TTL) return;

        boolean placed = airPlace.get() ? placeObsidianAir(pos, obs) : BlockUtils.place(pos, obs, rotate.get(), 50);
        if (placed) {
            lastBase = now;
            BlockPos imm = pos.toImmutable();
            pendingBase = imm;
            pendingTime = now;
            placedBlockCache.put(imm, now);
            acted = true;
            actedText = ts.get(0).getName().getString() + " obsidiana";
        }
    }

    /** Pone obsidiana en un hueco de aire pulsando sobre el propio hueco (el servidor lo coloca ahí). */
    private boolean placeObsidianAir(BlockPos p, FindItemResult obs) {
        boolean main = mc.player.getMainHandStack().isOf(Items.OBSIDIAN);
        boolean off = mc.player.getOffHandStack().isOf(Items.OBSIDIAN);
        final SwitchMode mode = switchMode.get();
        final boolean needSwap = !main && !off;
        if (needSwap && (obs.slot() > 8 || mode == SwitchMode.None)) return false;

        final BlockPos target = p;
        final Hand hand = (main || !off) ? Hand.MAIN_HAND : Hand.OFF_HAND;
        final Vec3d hit = Vec3d.ofCenter(target);

        Runnable action = () -> {
            boolean swapped = false;
            if (needSwap) swapped = InvUtils.swap(obs.slot(), mode == SwitchMode.Silent);
            mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(hit, Direction.UP, target, false));
            swing(hand);
            if (swapped && mode == SwitchMode.Silent) InvUtils.swapBack();
        };

        if (rotate.get()) {
            Rotations.rotate(Rotations.getYaw(hit), Rotations.getPitch(hit), 50, action);
        } else {
            action.run();
        }
        return true;
    }

    private Direction placeDir(BlockPos b) {
        if (!strictDirection.get()) return Direction.UP;

        Vec3d eye = mc.player.getEyePos();
        Vec3d c = Vec3d.ofCenter(b);
        Direction best = Direction.UP;
        double bestDist = Double.MAX_VALUE;

        for (Direction d : Direction.values()) {
            if (d == Direction.DOWN) continue;
            if (!mc.world.getBlockState(b.offset(d)).isAir()) continue;
            Vec3d face = c.add(d.getOffsetX() * 0.5, d.getOffsetY() * 0.5, d.getOffsetZ() * 0.5);
            double dist = eye.squaredDistanceTo(face);
            if (dist < bestDist) {
                bestDist = dist;
                best = d;
            }
        }
        return best;
    }

    private boolean visible(BlockPos base) {
        Vec3d top = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
        BlockHitResult r = mc.world.raycast(new RaycastContext(mc.player.getEyePos(), top,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return r.getType() == HitResult.Type.MISS
            || (r.getType() == HitResult.Type.BLOCK && r.getBlockPos().equals(base));
    }

    /**
     * Busca la mejor base alrededor de los objetivos.
     * forBase=false: bases de obsidiana/bedrock existentes.
     * forBase=true: huecos de aire donde se podría poner obsidiana (con apoyo, o sin él con air-place).
     */
    private BlockPos findPlace(List<LivingEntity> ts, boolean forBase, double[] out, long now) {
        double r = scanRadius.get();
        int ir = (int) Math.ceil(r);
        Vec3d eye = mc.player.getEyePos();
        double range = placeRange.get();

        Set<Long> seen = new HashSet<>();
        BlockPos bestPos = null;
        double bestDmg = 0, bestSelf = Double.MAX_VALUE;

        for (LivingEntity t : ts) {
            BlockPos tb = t.getBlockPos();
            for (int dx = -ir; dx <= ir; dx++) {
                for (int dy = -ir; dy <= ir; dy++) {
                    for (int dz = -ir; dz <= ir; dz++) {
                        if (dx * dx + dy * dy + dz * dz > r * r) continue;

                        BlockPos base = new BlockPos(tb.getX() + dx, tb.getY() + dy, tb.getZ() + dz);
                        if (!seen.add(base.asLong())) continue;

                        Vec3d crystal = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
                        double dist = eye.distanceTo(crystal);
                        if (dist > range) continue;

                        if (!validBase(base, forBase, now)) continue;

                        Long rp = recentPlace.get(base);
                        if (!forBase && rp != null && now - rp < 250) {
                            rej[R_RECENT]++;
                            continue;
                        }
                        if (dist > placeWalls.get() && !visible(base)) {
                            rej[R_RANGE]++;
                            continue;
                        }

                        cBases++;
                        // virtualBase: base aún no solidificada en el cliente (air-place reciente en caché).
                        boolean fromCache = !forBase && isCachedBase(base, now);
                        virtualBase = forBase || fromCache;
                        double[] ev;
                        try {
                            ev = evaluate(crystal, ts);
                        } finally {
                            virtualBase = false;
                        }
                        if (ev == null) continue;

                        if (ev[0] > bestDmg || (ev[0] == bestDmg && ev[1] < bestSelf)) {
                            bestDmg = ev[0];
                            bestSelf = ev[1];
                            bestPos = base.toImmutable();
                        }
                    }
                }
            }
        }

        if (bestPos != null) {
            out[0] = bestDmg;
            out[1] = bestSelf;
        }
        return bestPos;
    }

    /** Entidades que de verdad impiden colocar (ignora objetos y cristales recién golpeados). */
    private boolean blocksPlacement(Entity e) {
        if (!e.isAlive() || e.isSpectator() || e instanceof ItemEntity) return false;
        if (e instanceof EndCrystalEntity c) {
            Long h = hitTimes.get(c.getId());
            if (h != null && System.currentTimeMillis() - h < 250) return false;
        }
        return true;
    }

    private boolean isCachedBase(BlockPos base, long now) {
        Long t = placedBlockCache.get(base);
        return t != null && now - t <= PLACED_CACHE_TTL;
    }

    private boolean validBase(BlockPos base, boolean forBase, long now) {
        if (forBase) {
            if (!mc.world.getBlockState(base).isAir()) return false;
            // No intentar colocar otra obsidiana donde ya hay una en caché (evita doble air-place).
            if (isCachedBase(base, now)) return false;

            boolean support = false;
            for (Direction d : Direction.values()) {
                if (!mc.world.getBlockState(base.offset(d)).isReplaceable()) {
                    support = true;
                    break;
                }
            }
            if (!support && !airPlace.get()) return false;

            Box baseBox = new Box(base.getX(), base.getY(), base.getZ(), base.getX() + 1.0, base.getY() + 1.0, base.getZ() + 1.0);
            if (!mc.world.getOtherEntities(null, baseBox, this::blocksPlacement).isEmpty()) return false;
        } else {
            boolean isObs = mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(base).isOf(Blocks.BEDROCK);
            // Reutilizar la base recién colocada aunque el cliente aún no haya sincronizado el bloque.
            if (!isObs && !isCachedBase(base, now)) return false;
        }

        if (!mc.world.getBlockState(base.up()).isAir() || !mc.world.getBlockState(base.up(2)).isAir()) return false;

        Box box = new Box(base.getX(), base.getY() + 1.0, base.getZ(), base.getX() + 1.0, base.getY() + 3.0, base.getZ() + 1.0);
        return mc.world.getOtherEntities(null, box, this::blocksPlacement).isEmpty();
    }
}
