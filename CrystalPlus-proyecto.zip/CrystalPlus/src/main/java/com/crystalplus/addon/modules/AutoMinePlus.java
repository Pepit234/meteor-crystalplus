package com.crystalplus.addon.modules;

import com.crystalplus.addon.CrystalPlusAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.BlockBreakingProgressS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * AutoMinePlus: mina el surround (piernas / cabeza) del enemigo más cercano usando SpeedMinePlus
 * y vigila los bloques que otros jugadores intentan romper, mostrando su porcentaje.
 */
public class AutoMinePlus extends Module {
    public enum Priority { Leg, Head, Both }

    private static final int PRIO_AUTO = 5;
    private static final int PRIO_FACE = 8;

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgWatch = settings.createGroup("Vigilar");

    // ---- Minar enemigos ----
    private final BoolSetting mineEnemies = sgGeneral.add(new BoolSetting.Builder()
        .name("mine-enemies").description("Mina bloques alrededor del enemigo más cercano.").defaultValue(true).build());
    private final EnumSetting<Priority> priority = sgGeneral.add(new EnumSetting.Builder<Priority>()
        .name("priority").description("Zona del objetivo que se mina primero.").defaultValue(Priority.Leg).build());
    private final DoubleSetting targetRange = sgGeneral.add(new DoubleSetting.Builder()
        .name("target-range").description("Distancia máxima a los objetivos.").defaultValue(6.0).min(1.0).sliderRange(1.0, 10.0).build());
    private final BoolSetting raytrace = sgGeneral.add(new BoolSetting.Builder()
        .name("raytrace").description("Solo mina bloques que se ven.").defaultValue(false).build());
    private final BoolSetting ignoreNaked = sgGeneral.add(new BoolSetting.Builder()
        .name("ignore-naked").description("Ignora jugadores sin armadura.").defaultValue(false).build());
    private final BoolSetting avoidSharing = sgGeneral.add(new BoolSetting.Builder()
        .name("avoid-sharing").description("No mina bloques de tu propio surround.").defaultValue(true).build());
    private final BoolSetting face = sgGeneral.add(new BoolSetting.Builder()
        .name("face").description("Mina el bloque que tienes en la cara (trampas / phase).").defaultValue(true).build());

    // ---- Vigilar a otros jugadores ----
    private final BoolSetting watch = sgWatch.add(new BoolSetting.Builder()
        .name("watch-others").description("Muestra el % que otros jugadores llevan minando un bloque.").defaultValue(true).build());
    private final DoubleSetting watchRange = sgWatch.add(new DoubleSetting.Builder()
        .name("watch-range").description("Distancia máxima a la que se vigilan bloques.").defaultValue(10.0).min(2.0).sliderRange(2.0, 30.0).build());
    private final BoolSetting onlyMyProtection = sgWatch.add(new BoolSetting.Builder()
        .name("only-my-protection").description("Solo bloques pegados a ti (tu surround, cabeza y suelo).").defaultValue(false).build());
    private final BoolSetting showText = sgWatch.add(new BoolSetting.Builder()
        .name("show-text").description("Texto con nombre y porcentaje sobre el bloque.").defaultValue(true).build());
    private final BoolSetting showBox = sgWatch.add(new BoolSetting.Builder()
        .name("show-box").description("Resalta el bloque que están minando.").defaultValue(true).build());
    private final BoolSetting chatAlert = sgWatch.add(new BoolSetting.Builder()
        .name("chat-alert").description("Aviso en el chat al llegar al porcentaje indicado.").defaultValue(true).build());
    private final IntSetting alertPercent = sgWatch.add(new IntSetting.Builder()
        .name("alert-percent").description("Porcentaje que dispara el aviso.").defaultValue(50).min(10).max(100).sliderRange(10, 100).build());

    private static class Track {
        final int entityId;
        volatile int stage;
        volatile long time;
        boolean alerted;

        Track(int entityId) {
            this.entityId = entityId;
        }
    }

    private final Map<BlockPos, Track> tracks = new ConcurrentHashMap<>();

    public AutoMinePlus() {
        super(CrystalPlusAddon.CATEGORY, "auto-mine-plus", "Mina el surround del enemigo con SpeedMine y vigila quién intenta romper tu protección.");
    }

    @Override
    public void onActivate() {
        tracks.clear();
        SpeedMinePlus sm = Modules.get().get(SpeedMinePlus.class);
        if (sm != null && !sm.isActive()) sm.toggle();
    }

    @Override
    public void onDeactivate() {
        tracks.clear();
    }

    // ---------- Paquetes: progreso de otros jugadores ----------
    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (!watch.get()) return;

        if (event.packet instanceof BlockBreakingProgressS2CPacket p) {
            if (mc.player != null && p.getEntityId() == mc.player.getId()) return;

            BlockPos bp = p.getPos().toImmutable();
            int stage = p.getProgress();
            if (stage < 0 || stage > 9) {
                tracks.remove(bp);
                return;
            }

            Track t = tracks.get(bp);
            if (t == null || t.entityId != p.getEntityId()) {
                t = new Track(p.getEntityId());
                tracks.put(bp, t);
            }
            t.stage = stage;
            t.time = System.currentTimeMillis();
        } else if (event.packet instanceof BlockUpdateS2CPacket u) {
            if (u.getState().isAir()) tracks.remove(u.getPos());
        }
    }

    // ---------- Tick ----------
    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        updateWatch();
        if (!mineEnemies.get()) return;

        SpeedMinePlus sm = Modules.get().get(SpeedMinePlus.class);
        if (sm == null) return;
        if (!sm.isActive()) {
            sm.toggle();
            return;
        }

        if (face.get()) {
            BlockPos eye = BlockPos.ofFloored(mc.player.getEyePos());
            if (sm.canMine(eye)) {
                sm.handle(eye, PRIO_FACE);
                return;
            }
        }

        PlayerEntity target = findTarget();
        if (target == null) return;

        List<BlockPos> candidates = candidates(target, sm);
        BlockPos cur = sm.getPos();

        if (cur != null && sm.isBusy() && sm.getPriority() >= PRIO_AUTO) {
            if (candidates.contains(cur)) return;
            if (sm.isInstant() && cur.isWithinDistance(target.getBlockPos(), 3.0)) return;
        }
        if (candidates.isEmpty()) return;

        sm.handle(candidates.get(0), PRIO_AUTO);
    }

    private PlayerEntity findTarget() {
        PlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.getHealth() <= 0) continue;
            if (untargetable(p)) continue;
            if (Friends.get().isFriend(p)) continue;
            if (ignoreNaked.get() && naked(p)) continue;

            double d = mc.player.distanceTo(p);
            if (d > targetRange.get()) continue;
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    /** Reales en creativo/espectador no; el jugador falso de Meteor copia tu modo de juego y sí cuenta. */
    private boolean untargetable(PlayerEntity p) {
        if (!p.isCreative() && !p.isSpectator()) return false;
        return mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(p.getUuid()) != null;
    }

    private boolean naked(PlayerEntity p) {
        return p.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
            && p.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
            && p.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
            && p.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }

    private List<BlockPos> candidates(PlayerEntity target, SpeedMinePlus sm) {
        BlockPos feet = target.getBlockPos();
        Vec3d eye = mc.player.getEyePos();

        List<BlockPos> legs = new ArrayList<>();
        for (Direction d : Direction.Type.HORIZONTAL) {
            BlockPos p = feet.offset(d);
            if (valid(p, sm)) legs.add(p);
        }
        legs.sort(Comparator.comparingDouble(p -> eye.squaredDistanceTo(Vec3d.ofCenter(p))));

        List<BlockPos> heads = new ArrayList<>();
        BlockPos head = feet.up(2);
        if (valid(head, sm)) heads.add(head);

        List<BlockPos> out = new ArrayList<>();
        if (priority.get() == Priority.Head) {
            out.addAll(heads);
            out.addAll(legs);
        } else {
            out.addAll(legs);
            out.addAll(heads);
        }
        return out;
    }

    private boolean valid(BlockPos p, SpeedMinePlus sm) {
        if (!sm.canMine(p)) return false;
        if (avoidSharing.get() && isMySurround(p)) return false;
        if (raytrace.get() && !visible(p)) return false;
        return true;
    }

    private boolean isMySurround(BlockPos p) {
        BlockPos mine = mc.player.getBlockPos();
        for (Direction d : Direction.Type.HORIZONTAL) {
            if (mine.offset(d).equals(p)) return true;
        }
        return mine.up(2).equals(p);
    }

    private boolean visible(BlockPos p) {
        BlockHitResult r = mc.world.raycast(new RaycastContext(mc.player.getEyePos(), Vec3d.ofCenter(p),
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return r.getType() == HitResult.Type.MISS || (r.getType() == HitResult.Type.BLOCK && r.getBlockPos().equals(p));
    }

    // ---------- Vigilancia ----------
    private boolean nearMe(BlockPos p) {
        BlockPos me = mc.player.getBlockPos();
        int dy = p.getY() - me.getY();
        return Math.abs(p.getX() - me.getX()) <= 2 && Math.abs(p.getZ() - me.getZ()) <= 2 && dy >= -1 && dy <= 2;
    }

    private boolean relevant(BlockPos p) {
        if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)) > watchRange.get()) return false;
        return !onlyMyProtection.get() || nearMe(p);
    }

    private String nameOf(Track t) {
        Entity e = mc.world.getEntityById(t.entityId);
        return e != null ? e.getName().getString() : "Jugador";
    }

    private void updateWatch() {
        if (!watch.get() || tracks.isEmpty()) return;

        long now = System.currentTimeMillis();
        for (Map.Entry<BlockPos, Track> e : tracks.entrySet()) {
            BlockPos bp = e.getKey();
            Track t = e.getValue();

            if (now - t.time > 15000) {
                tracks.remove(bp);
                continue;
            }
            if (!chatAlert.get() || t.alerted || !relevant(bp)) continue;

            int pct = (t.stage + 1) * 10;
            if (pct < alertPercent.get()) continue;

            t.alerted = true;
            BlockState s = mc.world.getBlockState(bp);
            warning("%s está minando %s (%d%%) en %d, %d, %d%s", nameOf(t),
                s.getBlock().getName().getString(), pct, bp.getX(), bp.getY(), bp.getZ(),
                nearMe(bp) ? " - ¡TU PROTECCIÓN!" : "");
        }
    }

    private static Color stageColor(int stage, int alpha) {
        int r = 255;
        int g = Math.max(0, 255 - stage * 28);
        return new Color(r, g, 40, alpha);
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!watch.get() || !showBox.get() || tracks.isEmpty() || mc.player == null) return;
        for (Map.Entry<BlockPos, Track> e : tracks.entrySet()) {
            if (!relevant(e.getKey())) continue;
            int stage = e.getValue().stage;
            event.renderer.box(e.getKey(), stageColor(stage, 50), stageColor(stage, 255), ShapeMode.Both, 0);
        }
    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if (!watch.get() || !showText.get() || tracks.isEmpty() || mc.player == null || mc.world == null) return;

        TextRenderer text = TextRenderer.get();
        for (Map.Entry<BlockPos, Track> e : tracks.entrySet()) {
            BlockPos bp = e.getKey();
            if (!relevant(bp)) continue;

            Track t = e.getValue();
            String label = nameOf(t) + " " + ((t.stage + 1) * 10) + "%";

            Vector3d v = new Vector3d(bp.getX() + 0.5, bp.getY() + 1.2, bp.getZ() + 0.5);
            if (!NametagUtils.to2D(v, 1.0)) continue;

            NametagUtils.begin(v);
            text.beginBig();
            double w = text.getWidth(label, true);
            text.render(label, -w / 2.0, 0, stageColor(t.stage, 255), true);
            text.end();
            NametagUtils.end();
        }
    }

    @Override
    public String getInfoString() {
        int n = 0;
        for (Map.Entry<BlockPos, Track> e : tracks.entrySet()) {
            if (mc.player != null && relevant(e.getKey())) n++;
        }
        return n > 0 ? n + " minando" : null;
    }
}
