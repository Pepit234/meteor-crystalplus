package com.crystalplus.addon;

import com.crystalplus.addon.modules.AutoCrystalPlus;
import com.crystalplus.addon.modules.AutoMinePlus;
import com.crystalplus.addon.modules.SpeedMinePlus;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CrystalPlusAddon extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("CrystalPlus");
    public static final Category CATEGORY = new Category("CrystalPlus");

    @Override
    public void onInitialize() {
        LOG.info("Iniciando CrystalPlus");
        Modules.get().add(new AutoCrystalPlus());
        Modules.get().add(new SpeedMinePlus());
        Modules.get().add(new AutoMinePlus());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.crystalplus.addon";
    }
}
