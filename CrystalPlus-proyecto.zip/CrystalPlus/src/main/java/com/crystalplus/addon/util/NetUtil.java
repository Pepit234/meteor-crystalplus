package com.crystalplus.addon.util;

import com.crystalplus.addon.mixin.ClientWorldAccessor;
import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.network.packet.Packet;

import java.util.function.IntFunction;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/** Envía paquetes con número de secuencia válido (obligatorio en servidores modernos). */
public final class NetUtil {
    private NetUtil() {}

    public static void send(Packet<?> packet) {
        if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendPacket(packet);
    }

    public static void sendSequenced(IntFunction<Packet<?>> creator) {
        if (mc.world == null || mc.getNetworkHandler() == null) return;
        try (PendingUpdateManager manager = ((ClientWorldAccessor) mc.world).crystalplus$getPendingUpdateManager().incrementSequence()) {
            int sequence = manager.getSequence();
            mc.getNetworkHandler().sendPacket(creator.apply(sequence));
        }
    }
}
