# VOIDRA BASEHUNTER 26.2 — updated source

Client-side Meteor addon project targeting Minecraft 26.2, Fabric Loader 0.19.3 and Java 25.

## Modules
- **Base Block Radar**: highlights chests, barrels, ender chests, spawners and furnaces in loaded chunks.
- **Portal Radar**: highlights Nether portal blocks in loaded chunks.
- **Player Last Seen**: marks positions of player entities currently known to the client. This is not a server-side historical tracker.

## Build (Termux)
Use Java 25 and a Gradle version compatible with Fabric Loom 1.17.21.

```sh
cd /storage/emulated/0/Download/VOIDRA-BASEHUNTER-26.2-UPDATED
gradle build --no-configuration-cache
```

The JAR, if the build succeeds, will be in `build/libs/`.

## Important limitations
- These scanners only inspect chunks loaded and sent to your client. They cannot reveal unloaded chunks, hidden server data, or locations outside the received world.
- Player Last Seen only remembers players observed during the current module session; it cannot recover past positions from before the addon was enabled.
- The source is migrated to Mojang's named packages for Minecraft 26.2 (26.1+ no longer uses Yarn mappings).
- This archive has not been compiled in the target Termux environment. Dependency availability and the exact Meteor 26.2 snapshot API must be verified with the build command. No one can honestly guarantee a zero-error build without running that build against the same dependency versions.
