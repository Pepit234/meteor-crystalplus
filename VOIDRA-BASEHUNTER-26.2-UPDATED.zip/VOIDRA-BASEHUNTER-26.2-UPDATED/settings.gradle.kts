pluginManagement {
    repositories {
        maven("https://maven.fabricmc.net/")
        gradlePluginPortal()
        mavenCentral()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_PROJECT)
    repositories {
        maven("https://maven.meteordev.org/releases")
        maven("https://maven.meteordev.org/snapshots")
        maven("https://maven.fabricmc.net/")
        mavenCentral()
    }
}
rootProject.name = "VOIDRA-BASEHUNTER-26.2"
