package com.voidra.basehunter.modules;

import com.voidra.basehunter.VOIDRABaseHunter;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;

import java.util.LinkedHashSet;
import java.util.Set;

public class PortalRadar extends Module {
    private final Setting<Integer> radius = settings.getDefaultGroup().add(new IntSetting.Builder()
        .name("radius").description("Search radius for portals in loaded chunks.")
        .defaultValue(40).min(8).max(80).sliderMax(80).build());
    private final Setting<SettingColor> color = settings.getDefaultGroup().add(new ColorSetting.Builder()
        .name("color").defaultValue(new SettingColor(180, 70, 255, 100)).build());

    private final Set<BlockPos> portals = new LinkedHashSet<>();
    private int timer;

    public PortalRadar() {
        super(VOIDRABaseHunter.CATEGORY, "portal-radar",
            "Highlights Nether portal blocks in the currently loaded area.");
    }

    @Override
    public void onDeactivate() {
        portals.clear();
        timer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.level == null || mc.player == null || ++timer < 30) return;
        timer = 0;
        portals.clear();

        BlockPos origin = BlockPos.containing(mc.player.position());
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int r = radius.get();

        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                if (x * x + z * z > r * r) continue;
                for (int y = -16; y <= 16; y++) {
                    pos.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                    if (!mc.level.hasChunkAt(pos)) continue;
                    if (mc.level.getBlockState(pos).is(Blocks.NETHER_PORTAL)) portals.add(pos.immutable());
                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        for (BlockPos pos : portals) {
            event.renderer.box(pos, color.get(), color.get(), ShapeMode.Lines, 0);
        }
    }
}
