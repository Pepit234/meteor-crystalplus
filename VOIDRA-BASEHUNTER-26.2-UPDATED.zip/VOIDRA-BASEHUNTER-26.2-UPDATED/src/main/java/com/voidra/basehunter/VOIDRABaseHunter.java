package com.voidra.basehunter;

import com.voidra.basehunter.modules.BlockRadar;
import com.voidra.basehunter.modules.PlayerLastSeen;
import com.voidra.basehunter.modules.PortalRadar;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class VOIDRABaseHunter extends MeteorAddon {
    public static final Category CATEGORY = new Category("VOIDRA BaseHunter");

    @Override
    public void onInitialize() {
        Modules.get().add(new BlockRadar());
        Modules.get().add(new PortalRadar());
        Modules.get().add(new PlayerLastSeen());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.voidra.basehunter";
    }
}
