package com.voidra.basehunter.modules;

import com.voidra.basehunter.VOIDRABaseHunter;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;

import java.util.LinkedHashMap;
import java.util.Map;

public class BlockRadar extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Integer> radius = sg.add(new IntSetting.Builder()
        .name("radius").description("Search radius around the player.")
        .defaultValue(24).min(4).max(64).sliderMax(64).build());
    private final Setting<Integer> vertical = sg.add(new IntSetting.Builder()
        .name("vertical-range").description("Vertical range above and below the player.")
        .defaultValue(12).min(2).max(32).sliderMax(32).build());
    private final Setting<Boolean> chests = sg.add(new BoolSetting.Builder()
        .name("chests-and-barrels").defaultValue(true).build());
    private final Setting<Boolean> enderChests = sg.add(new BoolSetting.Builder()
        .name("ender-chests").defaultValue(true).build());
    private final Setting<Boolean> spawners = sg.add(new BoolSetting.Builder()
        .name("spawners").defaultValue(true).build());
    private final Setting<Boolean> furnaces = sg.add(new BoolSetting.Builder()
        .name("furnaces").defaultValue(true).build());
    private final Setting<SettingColor> storageColor = sg.add(new ColorSetting.Builder()
        .name("storage-color").defaultValue(new SettingColor(40, 220, 255, 80)).build());
    private final Setting<SettingColor> spawnerColor = sg.add(new ColorSetting.Builder()
        .name("spawner-color").defaultValue(new SettingColor(255, 60, 60, 90)).build());
    private final Setting<SettingColor> furnaceColor = sg.add(new ColorSetting.Builder()
        .name("furnace-color").defaultValue(new SettingColor(255, 170, 40, 80)).build());

    private final Map<BlockPos, Integer> found = new LinkedHashMap<>();
    private int timer;

    public BlockRadar() {
        super(VOIDRABaseHunter.CATEGORY, "base-block-radar",
            "Highlights storage blocks and activity clues in loaded chunks.");
    }

    @Override
    public void onDeactivate() {
        found.clear();
        timer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.level == null || mc.player == null || ++timer < 20) return;
        timer = 0;
        found.clear();

        BlockPos origin = BlockPos.containing(mc.player.position());
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int r = radius.get();
        int h = vertical.get();

        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                if (x * x + z * z > r * r) continue;
                for (int y = -h; y <= h; y++) {
                    pos.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                    if (!mc.level.hasChunkAt(pos)) continue;

                    var state = mc.level.getBlockState(pos);
                    if (chests.get() && (state.is(Blocks.CHEST) || state.is(Blocks.BARREL)
                        || state.is(Blocks.TRAPPED_CHEST))) found.put(pos.immutable(), 1);
                    else if (enderChests.get() && state.is(Blocks.ENDER_CHEST)) found.put(pos.immutable(), 2);
                    else if (spawners.get() && state.is(Blocks.SPAWNER)) found.put(pos.immutable(), 3);
                    else if (furnaces.get() && (state.is(Blocks.FURNACE) || state.is(Blocks.BLAST_FURNACE)
                        || state.is(Blocks.SMOKER))) found.put(pos.immutable(), 4);
                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        for (var entry : found.entrySet()) {
            SettingColor color = entry.getValue() == 3 ? spawnerColor.get()
                : entry.getValue() == 4 ? furnaceColor.get() : storageColor.get();
            event.renderer.box(entry.getKey(), color, color, ShapeMode.Lines, 0);
        }
    }
}
