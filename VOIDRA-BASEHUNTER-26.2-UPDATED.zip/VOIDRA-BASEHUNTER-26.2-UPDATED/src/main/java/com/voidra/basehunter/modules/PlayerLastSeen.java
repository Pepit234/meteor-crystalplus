package com.voidra.basehunter.modules;

import com.voidra.basehunter.VOIDRABaseHunter;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerLastSeen extends Module {
    private final Setting<SettingColor> color = settings.getDefaultGroup().add(new ColorSetting.Builder()
        .name("color").defaultValue(new SettingColor(255, 80, 80, 90)).build());

    private final Map<UUID, BlockPos> lastSeen = new LinkedHashMap<>();

    public PlayerLastSeen() {
        super(VOIDRABaseHunter.CATEGORY, "player-last-seen",
            "Marks the last position observed for players in your currently received client world.");
    }

    @Override
    public void onDeactivate() {
        lastSeen.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.level == null || mc.player == null) return;
        for (Player player : mc.level.players()) {
            if (player == mc.player) continue;
            lastSeen.put(player.getUUID(), BlockPos.containing(player.position()));
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        for (BlockPos pos : lastSeen.values()) {
            event.renderer.box(pos, color.get(), color.get(), ShapeMode.Lines, 0);
        }
    }
}
